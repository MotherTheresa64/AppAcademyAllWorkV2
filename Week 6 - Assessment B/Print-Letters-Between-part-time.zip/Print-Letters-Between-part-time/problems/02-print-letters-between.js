/***********************************************************************
You are given a recursive function, `printLettersBetween()`, that takes
a start and end letter and prints all the letters between them in order.
If the start letter comes before the end letter in the alphabet, the letters
should print out in alphabetical order.  Otherwise, it should print in reverse
alphabetical order. You are given an array of letters in the alphabet to work
with for this problem.

The code is almost working but unfortunately, there are a few bugs. Use
the debugging skills you've been practicing and the VSCode debugger to
identify and solve the bugs.

Examples:

const ALPHABET = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];

printLettersBetween("a", "c"); // startLetter comes before endLetter
// a
// b
// c

printLettersBetween("f", "d"); // startLetter comes after endLetter => reverse
// f
// e
// d

printLettersBetween("g", "g"); // startLetter equals endLetter
// g

***********************************************************************/

const ALPHABET = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];

function printLettersBetween(startLetter, endLetter) {
  // Print the letter
  console.log(startLetter);

  // Base Case: Stop the program when startLetter equals endLetter
  if (startLetter === endLetter) {
    return;
  }

  // If the starting letter is after than the ending
  // letter, decrease the index by one. Otherwise, increase
  // the index by one.
  if (ALPHABET.indexOf(startLetter) > ALPHABET.indexOf(endLetter)) {
    startLetter = ALPHABET[ALPHABET.indexOf(startLetter) - 1];
  } else {
    startLetter = ALPHABET[ALPHABET.indexOf(startLetter) + 1];
  }

  // Make a recursive call with the modified letter.
  printLettersBetween(startLetter, endLetter);
}

// Test cases
printLettersBetween("a", "c"); // startLetter comes before endLetter
printLettersBetween("f", "d"); // startLetter comes after endLetter => reverse
printLettersBetween("g", "g"); // startLetter equals endLetter


/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
try {
  module.exports = printLettersBetween;
} catch {
  module.exports = null;
}
