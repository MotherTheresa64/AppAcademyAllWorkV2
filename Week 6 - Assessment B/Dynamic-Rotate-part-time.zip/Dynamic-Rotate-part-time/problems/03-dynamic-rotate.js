/***********************************************************************
Write a function named `dynamicRotate(num)`. When invoked, the
`dynamicRotate` function will accept a number to be used as the
rotation amount and return a function. Positive numbers rotate
the array to the right and negative numbers rotate to the left.

The function returned by `dynamicRotate` will accept an array to
be rotated by the amount provided when `dynamicRotate` was
first invoked. It will return the original array mutated by
the given rotation.

Examples:

```js
let arr = ['a', 'b', 'c', 'd', 'e'];
rotateRightTwo = dynamicRotate(2);
rotateRightTwo(arr);
console.log(arr); // [ 'd', 'e', 'a', 'b', 'c' ]

let animals = ['wombat', 'koala', 'opossum', 'kangaroo'];
rotateLeftOne = dynamicRotate(-1);
rotateLeftOne(animals)
console.log(animals); // [ 'koala', 'opossum', 'kangaroo', 'wombat' ]
```
***********************************************************************/

function dynamicRotate(num) {
  // Returns a function that takes an array and rotates it based on the captured number (num)
  return function (arr) {
    const length = arr.length;
    
    // Handles any negative numbers and converts them to positive and reverses the direction of the flow
    if (num < 0) {
      num = length - Math.abs(num);
    }

    // Checks if the array is empty or if num is 0 if so then no rotation is needed
    if (length === 0 || num === 0) {
      return arr;
    }

    // Does the rotation via slice and concat
    const rotatedArray = arr.slice(-num).concat(arr.slice(0, -num));

    // changes the og array
    arr.length = 0;
    rotatedArray.forEach((item) => {
      arr.push(item);
    });
  };
}

// Test cases as provided above
let arr = ['a', 'b', 'c', 'd', 'e'];
let rotateRightTwo = dynamicRotate(2);
rotateRightTwo(arr);
console.log(arr); // [ 'd', 'e', 'a', 'b', 'c' ]

let animals = ['wombat', 'koala', 'opossum', 'kangaroo'];
let rotateLeftOne = dynamicRotate(-1);
rotateLeftOne(animals);
console.log(animals); // [ 'koala', 'opossum', 'kangaroo', 'wombat' ]


/*As requested it returns a function, rotates if there's positive numbers and rotates left if there's negative numbers*/

/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
try {
  module.exports = dynamicRotate;
} catch {
  module.exports = null;
}
